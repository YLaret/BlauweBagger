from random import randrange

# MQTT server configuration
mqtt_host = "192.168.1.149"
mqtt_user = ""
mqtt_password = ""
mqtt_port = 1883
mqtt_topic_prefix = "Pi-W-Temp-monitor"


